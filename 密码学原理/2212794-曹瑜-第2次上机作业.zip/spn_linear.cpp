﻿// spn_linear.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>


using namespace std;

const int NUM_PAIRS = 8000;

void substitution(int array[8], unordered_map<string, string>& s_rule) {
    for (int i = 0; i < 8; i += 4) { // 每四个一组
        string group;
        for (int j = 0; j < 4; ++j) {
            group += to_string(array[i + j]); // 将整数转换为字符串
        }
        if (s_rule.find(group) != s_rule.end()) {
            string substituted_group = s_rule[group];
            for (int j = 0; j < 4; ++j) {
                string substr = substituted_group.substr(j, 1); // 获取替换后的单个字符
                array[i + j] = stoi(substr); // 将字符转换为整数并存回原数组
            }
        }
    }
}

void convertToBinary(int num, int* L1, int* L2) {
    for (int i = 7; i >= 0; --i) {
        if (i >= 4) {
            L1[i - 4] = (num >> i) & 1;
        }
        else {
            L2[i] = (num >> i) & 1;
        }
    }
}


int main()
{

    unordered_map<string, string> s_rule = {
    {"1110", "0000"}, {"0100", "0001"}, {"1101", "0010"}, {"0001", "0011"},
    {"0010", "0100"}, {"1111", "0101"}, {"1011", "0110"}, {"1000", "0111"},
    {"0011", "1000"}, {"1010", "1001"}, {"0110", "1010"}, {"1100", "1011"},
    {"0101", "1100"}, {"1001", "1101"}, {"0000", "1110"}, {"0111", "1111"}
    };

    ifstream inputFile("input.txt");
    if (!inputFile) {
        cerr << "无法打开文件！" << endl;
        return 1;
    }

    
    vector<string> P(NUM_PAIRS);
    vector<string> C(NUM_PAIRS);
    


    int count[256]={0};  //计数器

    

    // 逐行读取明文密文对
    string line;
    for (int i = 0; i < NUM_PAIRS; ++i) {
        getline(inputFile, line);
        istringstream iss(line);   //隔空格读取字符串
        iss >> P[i];      
        iss >> C[i];     
    }

    // 关闭文件
    inputFile.close();
    int L1[4]={0};
    int L2[4]={0};

    for (int i = 0; i < 8000; i++) {
        int y[16];                       //开始对p[i]、c[i]明密文对的计数
        int x[16];

        for (int j = 0; j < 16; ++j) {
                                   // 将字符转换为数字并存储到数组中
            x[j] = P[i][j] - '0';
            y[j] = C[i][j] - '0';
        }

        
        // 生成所有可能的L1、L2取值组合
        for (int a = 0; a < 256; ++a) {
            // 将 a 转换为二进制，存储到 L1 和 L2 中
            convertToBinary(a, L1,  L2);

            //对每一组L1 L2 开始最内层循环
            int v[8];
           

            for (int k = 0; k < 4; k++) {
                v[k] = L1[k] ^ y[k + 4];       //v(盒2)=L1^y(盒2)
            }

            for (int k = 0; k < 4; k++) {
                v[k+4] =L2[k] ^ y[k + 12];       //v(盒4)=L2^y(盒4)
            }

            substitution(v, s_rule);     //v（盒24）进行s逆变换

            int z = x[4] ^ x[6] ^ x[7] ^ v[1] ^ v[3] ^ v[5] ^ v[7];

            if (z == 0) {
                count[a]++;
            }
        }

    }

    int max = 100;
    int key = 0;
    for (int i = 0; i < 256; i++) {
        if (count[i] > max) {
            max = count[i];
            key = i;
        }
    }
    cout <<"max count:" << max << endl;
 

    convertToBinary(key, L1, L2);

    cout << "key:";

    for (int i = 0; i < 4; i++) {
        cout << L1[i];
    }
    cout << " ";

    for (int i = 0; i < 4; i++) {
        cout << L2[i];
    }
 
}

